#include <fstream>
#include <vector>

Bool_t DEBUG = true;
Double_t DegtoRad = TMath::Pi()/180.0;

Double_t RotateTheta(Double_t ang);

void Myplot_matscan(TString inFile = "./matscan", TString outFile = "matscan.root")
{
  //TString inFilePath = "/eic/u/mposik/Fun4all/macros/macros/Mymatscan/Geometry/";
  TString inFilePath = "";
  //read in matscan results
  fstream fIN;
  fIN.open(Form("%s%s.dat",inFilePath.Data(),inFile.Data()),ios::in);
  if(!fIN) cout << "Can't open " << inFile << endl;

  vector<Double_t> Theta, Length, X0, Lambda, Phi, Len, Eta, ThetaPrime;

  Double_t ith,iphi,ilen,ix0,ilambda,iEta,ithprime;

  while(fIN >> ith >> iphi >> ilen >> ix0 >> ilambda)
    {
      if(ith!=90.0)
        {
          Theta.push_back(ith); Phi.push_back(iphi); 
          ithprime = RotateTheta(ith); ThetaPrime.push_back(ithprime);
          iEta = -1.0*TMath::Log(TMath::Tan(ithprime*DegtoRad/2.0)); Eta.push_back(iEta);
          Len.push_back(ilen); X0.push_back(ix0); Lambda.push_back(ilambda);      
          if(DEBUG) cout << "Theta " << ith << " ThetaPrime: " << ithprime << " Eta: " << iEta << " X0 : " << ix0 << endl;
        }
    }
  fIN.close();
  TFile *fRoot = new TFile(Form("%s%s",inFilePath.Data(),outFile.Data()),"UPDATE");
//make Plot
  TGraph *gmat = new TGraph(Eta.size(),&Eta[0],&X0[0]);
  TCanvas *c1 = new TCanvas("c1","mat");
  c1->cd(1);
  gmat->Draw("al");
  gmat->GetXaxis()->SetRangeUser(-4,4);
  gmat->SetTitle(inFile);
  gmat->Write(inFile);

}

Double_t RotateTheta(Double_t ang)
{
  Double_t thprime = 90.0 - ang;
  return thprime;
}
